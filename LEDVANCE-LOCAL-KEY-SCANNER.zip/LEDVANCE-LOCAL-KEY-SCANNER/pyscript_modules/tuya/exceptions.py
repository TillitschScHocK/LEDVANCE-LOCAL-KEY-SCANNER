class InvalidUserSession(Exception):
  pass

class InvalidAuthentication(Exception):
  pass

