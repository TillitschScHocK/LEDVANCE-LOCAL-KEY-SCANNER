TUYA_CLIENT_ID = "fx3fvkvusmw45d7jn8xh"
TUYA_SECRET_KEY = "A_armptsqyfpxa4ftvtc739ardncett3uy_cgqx3ku34mh5qdesd7fcaru3gx7tyurr"

# SYLVANIA - remove the lines above and uncomment these lines if you use SYLVANIA instead of LEDVANCE
#TUYA_CLIENT_ID = "creq75hn4vdg5qvrgryp"
#TUYA_SECRET_KEY = "A_ag4xcmp9rjttkj9yf9e8c3wfxry7yr44_wparh3scdv8dc7rrnuegaf9mqmn4snpk"

TUYA_ENDPOINT = "https://a1.tuyaeu.com/api.json"
TUYA_USER_AGENT = "TY-UA=APP/Android/1.1.6/SDK/null"
TUYA_COUNTRY_CODE = 43
TUYA_DEVICE_ID = "5fe5abb36728cce7b9cd2185625edccbd6d9bd787e40"